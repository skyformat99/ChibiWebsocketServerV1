#!/usr/bin/env bash

sudo killall civetweb 

sudo killall chibi-scheme 

chibi-scheme -r ./main.scm &

sleep .5

civetweb -listening_ports 8090 &

/usr/bin/google-chrome-stable http://localhost:8090/index.html &

#GUILE_LOAD_PATH="$PWD:$GUILE_LOAD_PATH" guile test.scm
#/media/stor/gentoo-files/execs/compilers/programs/scheme/guile/SSE/upstream/guile-websocket#
#sudo lighttpd -D -f /etc/lighttpd/lighttpd.conf
